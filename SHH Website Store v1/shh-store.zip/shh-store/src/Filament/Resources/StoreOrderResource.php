<?php

namespace ShhStore\Filament\Resources;

use App\Models\Node;
use App\Models\Server;
use App\Models\User;
use Filament\Actions\EditAction;
use Filament\Forms;
use Filament\Resources\Resource;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Tables;
use Filament\Tables\Table;
use ShhStore\Filament\Resources\StoreOrderResource\Pages;
use ShhStore\Models\StoreOrder;

class StoreOrderResource extends Resource
{
    protected static ?string $model = StoreOrder::class;

    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-shopping-cart';

    protected static string|\UnitEnum|null $navigationGroup = 'Store';

    protected static ?string $navigationLabel = 'Orders';

    protected static ?int $navigationSort = 3;

    public static function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('Order Details')
                    ->schema([
                        Forms\Components\TextInput::make('order_number')
                            ->disabled(),
                        Forms\Components\Select::make('user_id')
                            ->label('Linked Client')
                            ->options(fn () => User::query()->orderBy('username')->pluck('username', 'id'))
                            ->searchable()
                            ->preload(),
                        Forms\Components\Select::make('status')
                            ->options([
                                'pending' => 'Pending',
                                'paid' => 'Paid',
                                'processing' => 'Processing',
                                'active' => 'Active',
                                'unpaid' => 'Unpaid',
                                'suspended' => 'Suspended',
                                'cancelled' => 'Cancelled',
                                'refunded' => 'Refunded',
                            ])
                            ->required(),
                        Forms\Components\TextInput::make('amount')
                            ->disabled()
                            ->prefix('$'),
                        Forms\Components\TextInput::make('billing_cycle')
                            ->disabled(),
                        Forms\Components\TextInput::make('slots')
                            ->label('Slots')
                            ->disabled(),
                        Forms\Components\TextInput::make('payment_method')
                            ->disabled(),
                        Forms\Components\TextInput::make('transaction_id')
                            ->disabled(),
                        Forms\Components\Select::make('server_id')
                            ->label('Linked Server')
                            ->options(fn () => Server::query()->orderBy('name')->pluck('name', 'id'))
                            ->searchable()
                            ->preload()
                            ->live()
                            ->afterStateUpdated(function ($state, Forms\Set $set): void {
                                if (blank($state)) {
                                    return;
                                }

                                $nodeId = Server::query()->whereKey($state)->value('node_id');
                                if ($nodeId) {
                                    $set('node_id', $nodeId);
                                }
                            }),
                        Forms\Components\Select::make('node_id')
                            ->label('Linked Node')
                            ->options(fn () => Node::query()->orderBy('name')->pluck('name', 'id'))
                            ->searchable()
                            ->preload(),
                        Forms\Components\DateTimePicker::make('bill_due_at')
                            ->label('Bill Due At')
                            ->seconds(false),
                        Forms\Components\DateTimePicker::make('suspended_for_nonpayment_at')
                            ->label('Suspended For Non-Payment At')
                            ->disabled()
                            ->seconds(false),
                    ])->columns(2),

                Section::make('Customer Info')
                    ->schema([
                        Forms\Components\TextInput::make('customer_name')
                            ->disabled(),
                        Forms\Components\TextInput::make('customer_email')
                            ->disabled(),
                    ])->columns(2),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('order_number')
                    ->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('user.username')
                    ->label('Client')
                    ->searchable()
                    ->sortable()
                    ->placeholder('—'),
                Tables\Columns\TextColumn::make('customer_email')
                    ->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('product.name')
                    ->sortable(),
                Tables\Columns\TextColumn::make('server.name')
                    ->label('Server')
                    ->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\TextColumn::make('node.name')
                    ->label('Node')
                    ->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\TextColumn::make('amount')
                    ->money('usd')
                    ->sortable(),
                Tables\Columns\TextColumn::make('slots')
                    ->badge()
                    ->placeholder('—')
                    ->toggleable(),
                Tables\Columns\TextColumn::make('billing_cycle')
                    ->badge(),
                Tables\Columns\TextColumn::make('status')
                    ->badge()
                    ->color(fn (string $state): string => match ($state) {
                        'paid', 'active' => 'success',
                        'pending', 'processing' => 'warning',
                        'unpaid' => 'danger',
                        'cancelled', 'refunded' => 'danger',
                        'suspended' => 'gray',
                        default => 'secondary',
                    }),
                Tables\Columns\TextColumn::make('payment_method')
                    ->badge(),
                Tables\Columns\TextColumn::make('paid_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(),
                Tables\Columns\TextColumn::make('bill_due_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable()
                    ->color(fn ($state) => $state && $state->isPast() ? 'danger' : null),
                Tables\Columns\TextColumn::make('suspended_for_nonpayment_at')
                    ->label('Suspended At')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\TextColumn::make('created_at')
                    ->dateTime()
                    ->sortable(),
            ])
            ->defaultSort('created_at', 'desc')
            ->filters([
                Tables\Filters\SelectFilter::make('status')
                    ->options([
                        'pending' => 'Pending',
                        'paid' => 'Paid',
                        'processing' => 'Processing',
                        'active' => 'Active',
                        'unpaid' => 'Unpaid',
                        'suspended' => 'Suspended',
                        'cancelled' => 'Cancelled',
                        'refunded' => 'Refunded',
                    ]),
                Tables\Filters\SelectFilter::make('payment_method')
                    ->options([
                        'stripe' => 'Stripe',
                        'paypal' => 'PayPal',
                    ]),
                Tables\Filters\SelectFilter::make('billing_cycle')
                    ->options([
                        'monthly' => 'Monthly',
                        'quarterly' => 'Quarterly',
                        'annually' => 'Annually',
                    ]),
            ])
            ->recordActions([
                EditAction::make(),
            ]);
    }

    public static function getRelations(): array
    {
        return [];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListStoreOrders::route('/'),
            'edit' => Pages\EditStoreOrder::route('/{record}/edit'),
        ];
    }
}
